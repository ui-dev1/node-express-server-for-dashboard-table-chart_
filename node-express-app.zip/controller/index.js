const dashboardStats = require('../response/dashboardStats.json');
const discussionGuide = require('../response/discussionGuideSearchData.json');

exports.dashboardStats = (req, res, next) => {
    res.status(200).json({ data: dashboardStats });
}

exports.createdByMe = (req, res, next) => {
    res.status(200).json({ data: res.paginatedResults });
}

exports.createdByTeam = (req, res, next) => {
    res.status(200).json({ data: res.paginatedResults });
}
exports.favourites = (req, res, next) => {
    res.status(200).json({ data: res.paginatedResults });
}
exports.discussionGuideData = (req, res, next) => {
    res.status(200).json({ data: discussionGuide });
}