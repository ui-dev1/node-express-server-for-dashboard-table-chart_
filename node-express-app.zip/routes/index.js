const express = require('express');
const { dashboardStats, discussionGuideData, createdByMe, createdByTeam, favourites } = require('../controller');

const createdByMeJson = require('../response/createdByMe.json');
const createdByTeamJson = require('../response/createdByTeam.json');
const favouritesJson = require('../response/favourites.json');
const router = express.Router();

function paginatedResults(model) {
    // middleware function
    return (req, res, next) => {
        const { pageNumber, recordCount } = req.body;

        // calculating the starting and ending index
        const startIndex = (pageNumber - 1) * recordCount;
        const endIndex = pageNumber * recordCount;

        const results = {};
        if (endIndex < model.length) {
            results.next = {
                pageNumber: pageNumber + 1,
                recordCount: recordCount
            };
        }

        if (startIndex > 0) {
            results.previous = {
                pageNumber: pageNumber - 1,
                recordCount: recordCount
            };
        }
        results.totalRecords = model.length;
        results.value = model.slice(startIndex, endIndex);

        res.paginatedResults = results;
        next();
    };
}

router.post('/Dashboard/card-values', dashboardStats);
router.post('/Dashboard/discussion-guides-me', paginatedResults(createdByMeJson.value), createdByMe);
router.post('/Dashboard/discussion-guides-team', paginatedResults(createdByTeamJson.value), createdByTeam);
router.post('/Favorite/get', paginatedResults(favouritesJson.value), favourites);
router.post('/BusinessObjective/get-all', discussionGuideData);

module.exports = router